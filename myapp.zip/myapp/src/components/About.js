import React from 'react'

export default function About() {
  return (
    <div className='About'>
      <div className='img-container fadeLeft'>
      </div>
      <div className="container fadeRight">
            <h1>About our Visionary</h1>

            <p>Besides health care sector, he had a very keen interest in uplifting the academic arena of Madurai,to bring in quality education, to reach the unreached, and the following are the few of his contributions in academics.</p>
            <p>
                When Madurai Kamaraj University was started as Madurai University, Dr.P.Vadamalayan was the first syndicate member for life time, nominated by the then Chief minister Thiru.C.N.Annadurai. He was minstrumental in bringing Madurai Medical College. He was the founder president of SVN college, and Jeyaraj Nadar School. He was in the administrative board of the The American College and helped to bring in various departments.
            </p>
        </div>
    </div>
  )
}
